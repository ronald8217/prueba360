package net.bytebuddy.dynamic.scaffold;

public class MethodGraph {

}

package org.openqa.selenium;

public @interface WebDriver {

}

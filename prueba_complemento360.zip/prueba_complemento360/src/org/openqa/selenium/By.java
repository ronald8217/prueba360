package org.openqa.selenium;

public class By {

}
